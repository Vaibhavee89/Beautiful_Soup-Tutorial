import requests
from bs4 import BeautifulSoup
import pandas as pd

proxies = {
  "http": "http://10.10.1.10:3128",
  "https": "https://10.10.1.10:1080",
}

data = {'title': [], 'price': []}

def fetchAndSaveToFile(url, path):
  """Fetches the content from the given URL and saves it to the given file.

  Args:
    url: The URL to fetch the content from.
    path: The path to the file to save the content to.
  """

  r = requests.get(url, headers={'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'})
  encoded_text = r.text.encode("utf-8")
  soup = BeautifulSoup(r.text, 'html.parser')

  spans = soup.select("span.a-size-medium.a-color-base.a-text-normal")
  prices = soup.select("span.a-price")

  # Remove any missing values from the arrays.
  spans = [span.string for span in spans if span.string is not None]
  prices = [price.find("span").get_text() for price in prices if price.find("span") is not None]

  # Pad the shorter arrays with empty values.
  if len(spans) < len(prices):
    spans += [""] * (len(prices) - len(spans))
  elif len(prices) < len(spans):
    prices += [""] * (len(spans) - len(prices))

  # Add the data to the dictionary.
  for i in range(len(spans)):
    data["title"].append(spans[i])
    data["price"].append(prices[i])

  # Create the Pandas DataFrame.
  df = pd.DataFrame.from_dict(data)

  # Save the DataFrame to a CSV file.
  df.to_csv("data.csv", index=False)

# Fetch the data from the Amazon website and save it to a CSV file.
url = "https://www.amazon.in/s?k=iphone&crid=38RO14ESYJLSY&sprefix=iphone%2Caps%2C209&ref=nb_sb_noss_1"
fetchAndSaveToFile(url, "data.csv")
