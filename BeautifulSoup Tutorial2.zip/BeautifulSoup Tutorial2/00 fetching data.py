import requests

def fetchAndSaveToFile(url, path):
  """Fetches the content from the given URL and saves it to the given file.

  Args:
    url: The URL to fetch the content from.
    path: The path to the file to save the content to.
  """

  r = requests.get(url)
  # Encode the response text to UTF-8.
  encoded_text = r.text.encode("utf-8")
  with open(path, "wb") as f:
    f.write(encoded_text)

# Fetch the content from the given URL and save it to the given file.
url = "https://timesofindia.indiatimes.com/education/news/aicte-chairman-prof-t-g-sitharam-attends-industry-academia-integration-conclave-2023/articleshow/104658403.cms"
fetchAndSaveToFile(url, "data/times.html")
